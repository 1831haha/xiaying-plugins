#!/system/bin/sh
# clash 插件启动脚本（mihomo v1.19.34，server 插件）
# 职责：按分配端口生成 config.yaml，验 mihomo 摘要，拉起。
# 环境：PORT/SERVICE_PORT=管理方分配的端口，TMPDIR=私有临时目录。
# 端口约定：控制 API 用 PORT（健康检查 GET /version 走这里），
# 混合代理端口用 PORT+1（顺序分配下一般空闲；若被占，mihomo 启动失败，
# 服务日志会写 bind 失败，见 README）。
# 订阅：App 把订阅链接写进 $TMPDIR/clash/subscription.txt（私有目录，不进插件包）；
# 为空时不带 proxy-providers，纯 DIRECT 也能起（健康检查照常过）。
set -e
cd "$(dirname "$0")"
CTL_PORT="${PORT:-29578}"
MIXED_PORT=$((CTL_PORT + 1))
MIHOMO_SHA256="1369bebba2b7a6fe971fe6ece0cb5aa18c81e49c89dd8340f43e5e7583d3da36"

# 验二进制摘要（防篡改；不对就拒绝启动）
ACTUAL="$(sha256sum ./mihomo 2>/dev/null | cut -d' ' -f1)"
if [ "$ACTUAL" != "$MIHOMO_SHA256" ]; then
  echo "mihomo 摘要不符，拒绝启动：$ACTUAL"
  exit 1
fi

CFG_DIR="${TMPDIR:-/tmp}/clash"
mkdir -p "$CFG_DIR"
# 订阅由 App 拉取后写进 $CFG_DIR/sub.yaml（私有目录）：
# App 用 Clash UA 拉订阅（面板只认 Clash UA 才回配置，裸 curl 回空），
# 校验含 proxies: 顶层键才落盘；mihomo 用 file 型 provider 读它，
# 不走 HTTP 拉取（省得再碰 UA 问题）。没有 sub.yaml 就纯 DIRECT 照常起。
HAS_SUB=0
if [ -s "$CFG_DIR/sub.yaml" ]; then
  HAS_SUB=1
fi

# 生成 config.yaml（App 只把需要走代理的源的流量发到混合端口，
# 所以规则就是 MATCH 走 PROXY 组，不用按域名分流；
# PROXY 是 url-test 组，自动挑延迟最低的节点，不用调控制 API 选节点）
{
  echo "mixed-port: $MIXED_PORT"
  echo "external-controller: 127.0.0.1:$CTL_PORT"
  echo "allow-lan: false"
  echo "mode: rule"
  echo "log-level: info"
  echo "unified-delay: true"
  echo "tcp-concurrent: true"
  if [ "$HAS_SUB" = "1" ]; then
    echo "proxy-providers:"
    echo "  sub:"
    echo "    type: file"
    echo "    path: ./sub.yaml"
    # v1.19.34.1：订阅文件重读间隔 300 秒（原 3600）——运行中更新订阅后，
    # 新节点最长 5 分钟内生效，不用等一小时；想立刻生效就重启服务。
    echo "    interval: 300"
    echo "    health-check:"
    echo "      enable: true"
    echo "      url: http://www.gstatic.com/generate_204"
    echo "      interval: 300"
    echo "proxy-groups:"
    echo "  - name: PROXY"
    echo "    type: url-test"
    echo "    url: http://www.gstatic.com/generate_204"
    echo "    interval: 300"
    echo "    use:"
    echo "      - sub"
    echo "rules:"
    echo "  - MATCH,PROXY"
  else
    echo "rules:"
    echo "  - MATCH,DIRECT"
  fi
} > "$CFG_DIR/config.yaml"

# v1.3.28：mihomo 是原生 ELF，共享存储上的 ELF 直接 exec 会被系统拒
# （error=13；T4-PHP 的 php 即便在私有目录也一样，只能走 linker64）。
# 本脚本自己调 mihomo，App 的 linker64 回退只管 exe（即本脚本）够不着它，
# 所以这里自己分流：有 linker64 就走它（只读文件映射，不要求 +x，
# 解压出来的 mihomo 默认 644 也能跑）；没有才直接 exec。
if [ -x /system/bin/linker64 ]; then
  exec /system/bin/linker64 ./mihomo -d "$CFG_DIR" -f "$CFG_DIR/config.yaml"
else
  exec ./mihomo -d "$CFG_DIR" -f "$CFG_DIR/config.yaml"
fi
