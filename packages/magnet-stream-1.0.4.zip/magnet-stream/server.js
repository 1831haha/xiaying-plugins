/**
 * magnet-stream: 磁力转 HTTP 视频流服务（DsPlayer server 插件）
 *
 *  GET /healthz                  -> {"ok":true}
 *  GET /status                   -> 当前任务简况（含 autoClean 开关状态）
 *  GET /warm?magnet=<urlencoded>  -> 预热：把磁链加入下载队列，立即返回（供详情页提前触发元数据获取）
 *  GET /stream?magnet=<urlencoded magnet>&index=<n,可选>
 *      -> 选中文件（缺省最大视频文件）的视频流，支持 Range（206）
 *         元数据未就绪时先回 200+chunked 响应头占住播放器连接，
 *         避免播放器 5 秒无响应超时；就绪后再续传数据。
 *         后续 seek 会开新连接走 206 快路径。
 *  POST /stop {magnet, clean?}    -> 提前释放某个任务；clean:true 同时删除已下载文件
 *  POST /clean {magnet?}          -> 手动清理：销毁任务并删除已下载文件；
 *      GET /clean?magnet=<可选>     不带 magnet 只清理 30 分钟未改动且不属于存活任务的孤儿文件
 *                                    （保护正在播放/刚加的任务；手机浏览器直接打开即可）
 *  POST /config {autoClean: true|false} -> 开关"自动清理"：开启后任务 15 分钟闲置释放时
 *      GET /config?autoClean=1|0    自动删除已下载文件；配置持久化在 data/config.json
 *                                    （手机浏览器打开 http://127.0.0.1:17890/config?autoClean=1 即开）
 *
 * 自动清理也可用环境变量 AUTO_CLEAN=1 强制开启（优先级高于配置文件）。
 *
 * 数据目录：$DS_PLUGIN_DIR/data（持久化，覆盖安装保留思路见 server 包说明）
 * 监听 127.0.0.1:$PORT（PORT 缺省 17890，可用环境变量覆盖）
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import WebTorrent from 'webtorrent';

const PORT = parseInt(process.env.PORT || '17890', 10);
const HOST = '127.0.0.1';
const VERSION = '1.0.4';
const META_TIMEOUT_MS = parseInt(process.env.META_TIMEOUT_MS || '120000', 10); // 磁链取元数据超时

// 崩溃可见：任何未捕获异常都打到服务日志，避免静默死亡无法排查
process.on('uncaughtException', (err) => {
  console.error(`[magnet-stream] UNCAUGHT EXCEPTION: ${(err && err.stack) || err}`);
});
process.on('unhandledRejection', (reason) => {
  console.error(`[magnet-stream] UNHANDLED REJECTION: ${(reason && reason.stack) || reason}`);
});
const IDLE_DESTROY_MS = 15 * 60 * 1000; // 15 分钟无人访问则释放任务

// 公开 tracker：DHT 慢时帮助更快拿到元数据/peer
const TRACKERS = [
  'udp://tracker.opentrackr.org:1337/announce',
  'udp://open.stealth.si:80/announce',
  'udp://exodus.desync.com:6969/announce',
  'udp://tracker.torrent.eu.org:451/announce',
];

const DATA_DIR = process.env.DS_PLUGIN_DIR
  ? path.join(process.env.DS_PLUGIN_DIR, 'data')
  : path.join(process.cwd(), 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

// 自动清理配置：data/config.json 持久化，缺省关闭；环境变量 AUTO_CLEAN=1 强制开启
const CONFIG_PATH = path.join(DATA_DIR, 'config.json');
let config = { autoClean: false };
try {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  const parsed = JSON.parse(raw);
  if (parsed && typeof parsed.autoClean === 'boolean') config.autoClean = parsed.autoClean;
} catch { /* 无配置文件则用缺省 */ }
function saveConfig() {
  try { fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2)); } catch { /* ignore */ }
}
function autoCleanEnabled() {
  if (process.env.AUTO_CLEAN === '1' || process.env.AUTO_CLEAN === 'true') return true;
  return config.autoClean === true;
}

// 释放任务；destroyStore=true 时同时删除该任务已下载的文件
function destroyTorrent(t, destroyStore) {
  const h = String(t.infoHash || '').toLowerCase();
  if (h && idleTimers.has(h)) { clearTimeout(idleTimers.get(h)); idleTimers.delete(h); }
  try { t.destroy({ destroyStore: !!destroyStore }); } catch { /* ignore */ }
}

const client = new WebTorrent({ dht: true, tracker: true });
const idleTimers = new Map(); // infoHash -> timeout

const VIDEO_EXT = new Set(['mp4', 'mkv', 'avi', 'mov', 'webm', 'm4v', 'ts', 'm2ts', 'flv', 'rmvb', 'wmv', '3gp', 'mpg', 'mpeg']);
const MIME = {
  mp4: 'video/mp4', m4v: 'video/x-m4v', mkv: 'video/x-matroska', avi: 'video/x-msvideo',
  mov: 'video/quicktime', webm: 'video/webm', ts: 'video/mp2t', m2ts: 'video/mp2t',
  flv: 'video/x-flv', rmvb: 'application/vnd.rn-realmedia-vbr', wmv: 'video/x-ms-wmv',
  '3gp': 'video/3gpp', mpg: 'video/mpeg', mpeg: 'video/mpeg',
};
const extOf = (n) => (String(n).split('.').pop() || '').toLowerCase();

function pickFile(torrent, index) {
  const files = torrent.files || [];
  if (index != null && !Number.isNaN(index) && files[index]) return files[index];
  const videos = files.filter((f) => VIDEO_EXT.has(extOf(f.name)));
  const pool = videos.length ? videos : files;
  if (!pool.length) return null;
  return pool.slice().sort((a, b) => b.length - a.length)[0];
}

function touchIdle(torrent) {
  const h = torrent.infoHash;
  if (!h) return;
  if (idleTimers.has(h)) clearTimeout(idleTimers.get(h));
  idleTimers.set(
    h,
    setTimeout(() => {
      idleTimers.delete(h);
      // 15 分钟无人访问：释放任务；自动清理开启时顺带删掉已下载文件
      destroyTorrent(torrent, autoCleanEnabled());
    }, IDLE_DESTROY_MS),
  );
}

function metaReady(t) {
  return !!(t.infoHash && t.files && t.files.length);
}

function infoHashOf(magnet) {
  const m = /btih:([a-zA-Z0-9]{40})/i.exec(magnet || '');
  return m ? m[1].toLowerCase() : null;
}

function findTorrent(magnet) {
  const h = infoHashOf(magnet);
  if (!h) return null;
  return client.torrents.find((t) => String(t.infoHash || '').toLowerCase() === h) || null;
}

function withTrackers(magnet) {
  if (!magnet.startsWith('magnet:')) return magnet;
  let out = magnet;
  for (const tr of TRACKERS) {
    const enc = encodeURIComponent(tr);
    if (out.indexOf(enc) < 0 && out.indexOf(tr) < 0) out += '&tr=' + enc;
  }
  return out;
}

// 取到已存在的任务，没有则新建（按 infoHash 去重，避免重复 add）
function ensureTorrent(magnet) {
  let t = findTorrent(magnet);
  if (t) {
    touchIdle(t);
    return t;
  }
  t = client.add(withTrackers(magnet), { path: DATA_DIR });
  touchIdle(t);
  return t;
}

// 等待元数据就绪（ready 事件），超时/出错/客户端断开则 reject
function waitReady(t, ms, isAborted) {
  return new Promise((resolve, reject) => {
    if (metaReady(t)) {
      resolve(t);
      return;
    }
    const to = setTimeout(() => {
      cleanup();
      reject(new Error('metadata timeout'));
    }, ms);
    // 播放器中途断开就别再傻等了，每秒检查一次
    const abortTimer = setInterval(() => {
      if (isAborted && isAborted()) {
        cleanup();
        reject(new Error('client aborted'));
      }
    }, 1000);
    const onReady = () => { cleanup(); resolve(t); };
    const onError = (e) => { cleanup(); reject(e instanceof Error ? e : new Error(String(e))); };
    const cleanup = () => {
      clearTimeout(to);
      clearInterval(abortTimer);
      t.removeListener('ready', onReady);
      t.removeListener('error', onError);
    };
    t.once('ready', onReady);
    t.once('error', onError);
  });
}

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve) => {
    let s = '';
    req.on('data', (c) => { s += c; });
    req.on('end', () => resolve(s));
  });
}

function parseRangeStart(rangeHeader) {
  if (!rangeHeader) return 0;
  const m = /bytes=(\d*)-/.exec(rangeHeader);
  if (!m || m[1] === '') return 0;
  const n = parseInt(m[1], 10);
  return Number.isNaN(n) || n < 0 ? 0 : n;
}

// 元数据已就绪：标准 Range/206 快路径
function serveReady(torrent, index, req, res) {
  const file = pickFile(torrent, index);
  if (!file) {
    sendJson(res, 404, { error: 'no file' });
    return;
  }
  const total = file.length;
  const type = MIME[extOf(file.name)] || 'application/octet-stream';
  const range = req.headers.range;

  if (range) {
    const m = range.match(/bytes=(\d*)-(\d*)/);
    let start = m && m[1] !== '' ? parseInt(m[1], 10) : 0;
    let end = m && m[2] !== '' ? parseInt(m[2], 10) : total - 1;
    if (Number.isNaN(start) || start < 0) start = 0;
    if (Number.isNaN(end) || end >= total) end = total - 1;
    if (start >= total) {
      res.writeHead(416, { 'Content-Range': `bytes */${total}` });
      res.end();
      return;
    }
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${total}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': end - start + 1,
      'Content-Type': type,
    });
    pipeFile(file, { start, end }, res);
  } else {
    res.writeHead(200, {
      'Content-Length': total,
      'Accept-Ranges': 'bytes',
      'Content-Type': type,
    });
    pipeFile(file, {}, res);
  }
  touchIdle(torrent);
}

// 带错误保护的推流：任何一边出错都不炸进程
function pipeFile(file, range, res) {
  try {
    const stream = file.createReadStream(range);
    stream.on('error', (e) => {
      console.error(`[magnet-stream] file stream error: ${(e && e.message) || e}`);
      try { res.destroy(); } catch { /* ignore */ }
    });
    res.on('error', () => {
      try { stream.destroy(); } catch { /* ignore */ }
    });
    stream.pipe(res);
  } catch {
    try { res.end(); } catch { /* ignore */ }
  }
}

// 元数据未就绪：先回响应头占住播放器连接，拿到元数据后再续传
async function serveWaiting(torrent, index, req, res) {
  const start = parseRangeStart(req.headers.range);
  // 立刻回 200 + chunked，把响应头发出去，避免播放器因 5 秒无响应而超时断开。
  // Content-Type 此时只能占位（mpv/ffmpeg 会按实际字节嗅探封装格式）；seek 会开新连接走 206 快路径。
  res.writeHead(200, {
    'Content-Type': 'video/mp4',
    'Transfer-Encoding': 'chunked',
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
  });
  if (typeof res.flushHeaders === 'function') res.flushHeaders();

  // 播放器中途断开（超时/切集/退出）时，及时放弃等待，不再往已死连接推流
  let aborted = false;
  const onClose = () => { aborted = true; };
  req.on('close', onClose);
  res.on('close', onClose);

  let t;
  try {
    t = await waitReady(torrent, META_TIMEOUT_MS, () => aborted);
  } catch (e) {
    // 元数据失败（无做种/DHT 不通）或客户端已断开：结束流
    try { res.end(); } catch { /* ignore */ }
    return;
  } finally {
    req.removeListener('close', onClose);
    res.removeListener('close', onClose);
  }
  if (aborted) return;
  const file = pickFile(t, index);
  if (!file) {
    try { res.end(); } catch { /* ignore */ }
    return;
  }
  const s = start >= file.length ? 0 : start;
  try {
    const stream = file.createReadStream({ start: s });
    // 推流双方任何一边出错都不应炸掉整个进程
    stream.on('error', (e) => {
      console.error(`[magnet-stream] file stream error: ${(e && e.message) || e}`);
      try { res.destroy(); } catch { /* ignore */ }
    });
    res.on('error', () => {
      try { stream.destroy(); } catch { /* ignore */ }
    });
    stream.pipe(res);
  } catch {
    try { res.end(); } catch { /* ignore */ }
  }
  touchIdle(t);
}

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x');

    if (u.pathname === '/healthz') {
      sendJson(res, 200, { ok: true, version: VERSION, torrents: client.torrents.length, autoClean: autoCleanEnabled() });
      return;
    }

    // 让新版本在端口被占时能请旧实例退出，实现自愈升级（仅本机回环可达）
    if (u.pathname === '/shutdown') {
      sendJson(res, 200, { ok: true, version: VERSION, shuttingDown: true });
      setTimeout(() => {
        console.log(`[magnet-stream] shutdown requested, v${VERSION} exiting`);
        process.exit(0);
      }, 300);
      return;
    }

    if (u.pathname === '/status') {
      sendJson(res, 200, {
        ok: true,
        version: VERSION,
        autoClean: autoCleanEnabled(),
        torrents: client.torrents.map((t) => ({
          infoHash: t.infoHash,
          name: t.name,
          ready: metaReady(t),
          progress: Number((t.progress || 0).toFixed(3)),
          peers: (t.numPeers || 0),
          downSpeed: t.downloadSpeed || 0,
          downloaded: t.downloaded || 0,
        })),
      });
      return;
    }

    // 预热：详情页打开时调用，提前开始找元数据；立即返回
    if (u.pathname === '/warm') {
      const magnet = u.searchParams.get('magnet') || '';
      if (!magnet.startsWith('magnet:')) {
        sendJson(res, 400, { ok: false, error: 'missing magnet' });
        return;
      }
      try {
        const t = ensureTorrent(magnet);
        sendJson(res, 200, { ok: true, infoHash: t.infoHash || infoHashOf(magnet), ready: metaReady(t) });
      } catch (e) {
        sendJson(res, 500, { ok: false, error: String((e && e.message) || e) });
      }
      return;
    }

    if (u.pathname === '/stop' && req.method === 'POST') {
      let magnet = '';
      let clean = false;
      try {
        const body = JSON.parse(await readBody(req));
        magnet = body.magnet || '';
        clean = body.clean === true;
      } catch { /* ignore */ }
      const t = findTorrent(magnet);
      if (t) destroyTorrent(t, clean);
      sendJson(res, 200, { ok: true, cleaned: !!t && clean });
      return;
    }

    // 手动清理：销毁任务并删除已下载文件，同时清扫已释放任务残留的孤儿文件。
    // 不带 magnet：只动 30 分钟以上未改动且不属于存活任务的文件（保护正在播放/刚加的任务）。
    // 手机浏览器可直接用 GET 打开（/clean 或 /clean?magnet=xxx）。
    if (u.pathname === '/clean' && (req.method === 'POST' || req.method === 'GET')) {
      let magnet = u.searchParams.get('magnet') || '';
      if (req.method === 'POST') {
        try { magnet = JSON.parse(await readBody(req)).magnet || magnet; } catch { /* ignore */ }
      }
      let cleaned = 0;
      let bytes = 0;
      const rmdir = (p) => {
        // 递归统计并删除
        let size = 0;
        try {
          const st = fs.statSync(p);
          if (st.isDirectory()) {
            for (const e of fs.readdirSync(p)) size += rmdir(path.join(p, e));
            fs.rmdirSync(p);
          } else {
            size = st.size;
            fs.unlinkSync(p);
          }
        } catch { /* ignore */ }
        return size;
      };
      if (magnet) {
        const t = findTorrent(magnet);
        if (t) {
          bytes += t.downloaded || 0;
          destroyTorrent(t, true);
          cleaned = 1;
        }
      } else {
        // 1) 销毁存活任务（30 分钟内用过的跳过保护）
        for (const t of [...client.torrents]) {
          const h = String(t.infoHash || '').toLowerCase();
          if (h && idleTimers.has(h)) continue;
          bytes += t.downloaded || 0;
          destroyTorrent(t, true);
          cleaned++;
        }
        // 2) 清扫孤儿文件：存活任务占用的顶层目录/文件 + config.json 之外，
        //    且 30 分钟未改动的，一律视为残留删除
        const ORPHAN_SAFE_MS = 30 * 60 * 1000;
        const liveTop = new Set();
        for (const t of client.torrents) {
          for (const f of (t.files || [])) {
            const seg = String(f.path || '').split('/')[0];
            if (seg) liveTop.add(seg);
          }
        }
        let entries = [];
        try { entries = fs.readdirSync(DATA_DIR); } catch { /* ignore */ }
        for (const e of entries) {
          if (e === 'config.json') continue;
          if (liveTop.has(e)) continue;
          const p = path.join(DATA_DIR, e);
          let st;
          try { st = fs.statSync(p); } catch { continue; }
          if (Date.now() - st.mtimeMs < ORPHAN_SAFE_MS) continue; // 30 分钟内改动过：不动
          const freed = rmdir(p);
          if (freed > 0) { bytes += freed; cleaned++; }
        }
      }
      sendJson(res, 200, { ok: true, cleaned, approxBytesFreed: bytes });
      return;
    }

    // 自动清理开关：POST /config {"autoClean": true|false}，
    // 或手机浏览器直接 GET /config?autoClean=1|0；持久化到 data/config.json
    if (u.pathname === '/config' && (req.method === 'POST' || req.method === 'GET')) {
      let want;
      const q = u.searchParams.get('autoClean');
      if (req.method === 'GET' && q == null) {
        // 手机浏览器直接打开 /config：只查看当前状态
        sendJson(res, 200, { ok: true, autoClean: autoCleanEnabled() });
        return;
      }
      if (req.method === 'GET') {
        want = q === '1' || q.toLowerCase() === 'true';
      } else {
        try { want = JSON.parse(await readBody(req)).autoClean; } catch { /* ignore */ }
      }
      if (typeof want !== 'boolean') {
        sendJson(res, 400, { ok: false, error: 'body.autoClean must be boolean' });
        return;
      }
      config.autoClean = want;
      saveConfig();
      sendJson(res, 200, { ok: true, autoClean: autoCleanEnabled() });
      return;
    }

    if (u.pathname === '/stream') {
      const magnet = u.searchParams.get('magnet') || '';
      if (!magnet.startsWith('magnet:')) {
        sendJson(res, 400, { error: 'missing magnet' });
        return;
      }
      const rawIdx = u.searchParams.get('index');
      const index = rawIdx == null ? null : parseInt(rawIdx, 10);

      let torrent;
      try {
        torrent = ensureTorrent(magnet);
      } catch (e) {
        sendJson(res, 504, { error: 'torrent add failed: ' + String((e && e.message) || e) });
        return;
      }
      if (metaReady(torrent)) {
        serveReady(torrent, index, req, res);
      } else {
        await serveWaiting(torrent, index, req, res);
      }
      return;
    }

    sendJson(res, 404, { error: 'not found' });
  } catch (e) {
    try {
      sendJson(res, 500, { error: String((e && e.message) || e) });
    } catch { /* ignore */ }
  }
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function probeHealth() {
  return new Promise((resolve) => {
    const req = http.get({ host: HOST, port: PORT, path: '/healthz', timeout: 3000 }, (res) => {
      let s = '';
      res.on('data', (c) => { s += c; });
      res.on('end', () => {
        try { resolve(JSON.parse(s)); } catch { resolve({ ok: true }); }
      });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
  });
}

function requestShutdown() {
  return new Promise((resolve) => {
    const req = http.get({ host: HOST, port: PORT, path: '/shutdown', timeout: 3000 }, (res) => {
      res.resume();
      res.on('end', () => resolve(res.statusCode));
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
  });
}

function listenOnce() {
  return new Promise((resolve) => {
    const onError = (err) => {
      server.removeListener('listening', onListening);
      resolve(err);
    };
    const onListening = () => {
      server.removeListener('error', onError);
      resolve(null);
    };
    server.once('error', onError);
    server.once('listening', onListening);
    server.listen(PORT, HOST);
  });
}

// 启动并处理端口被旧实例占用的情况：
// 新实例会请旧实例（v1.0.2+ 才有 /shutdown）退出后接管；
// 若是更老版本（无 /shutdown），则给出明确提示并退出，避免新旧打架。
async function startWithTakeover() {
  for (let attempt = 1; attempt <= 4; attempt++) {
    const err = await listenOnce();
    if (!err) {
      console.log(`[magnet-stream] v${VERSION} listening on ${HOST}:${PORT}`);
      return;
    }
    if (!err || err.code !== 'EADDRINUSE') {
      console.error(`[magnet-stream] failed to listen on ${HOST}:${PORT}:`, err);
      process.exit(1);
    }
    const info = await probeHealth();
    if (info && info.ok) {
      const v = info.version || '1.0.x（无版本自报）';
      console.log(`[magnet-stream] port ${PORT} busy, held by v${v}; requesting shutdown (attempt ${attempt})...`);
      const code = await requestShutdown();
      if (code === 200) {
        await sleep(2500);
        continue; // 旧实例应已退出，重试绑定
      }
      console.error(
        `[magnet-stream] port ${PORT} is held by an older instance (v${v}) that cannot shut down itself. ` +
        `Please STOP the magnet-stream service on the service page (or reboot the phone), then start it again.`,
      );
      process.exit(2);
    }
    console.error(`[magnet-stream] port ${PORT} busy but holder not responding; stop the old service first.`);
    process.exit(2);
  }
  console.error(`[magnet-stream] could not bind ${HOST}:${PORT} after takeover attempts.`);
  process.exit(2);
}

startWithTakeover();
