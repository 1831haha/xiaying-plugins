# Clash 代理插件（mihomo v1.19.34，server 型插件）

## 这是什么
把 clash（mihomo）做成侠影的 server 插件，不塞进主包。装好后手机里起一个
只绑 127.0.0.1 的本地代理，需要 VPN 的源把流量发到它上面走，不需要的源一点不受影响。

## 包内容
- `mihomo`：官方 release v1.19.34 的 Android arm64 静态二进制
  （SHA-256 `1369bebba2b7a6fe971fe6ece0cb5aa18c81e49c89dd8340f43e5e7583d3da36`，
  启动脚本会先验摘要再拉起）
- `start.sh`：启动脚本（server.json 的 command，摘要锚定在 server.json 里）
- `server.json`：server 插件规范 v1（port=0 由管理方从 29578 起分配）
- `README.md`：本文件

## 端口约定
- 控制 API 用分配到的端口（`PORT`），健康检查 `GET /version` 走这里。
- 混合代理端口（HTTP/SOCKS5）用 `PORT+1`。顺序分配下一般空闲；如果后来装的
  别的服务正好占了 `PORT+1`，clash 启动会报 bind 失败，服务日志里能看到，
  重装一次（换个分配端口）即可。v1 已知限制，不藏着。

## 订阅
- 订阅链接存在 App 私有 prefs 里，不进插件包、不进仓库。
- App 拉订阅时必须带 Clash UA（面板只认 Clash UA 才回配置，裸请求回空），
  校验含 `proxies:` 顶层键才落盘到私有目录 `$TMPDIR/clash/sub.yaml`；
  mihomo 用 file 型 provider 读它，不走 HTTP 拉取。
- 没拉到订阅也能启动（纯 DIRECT），健康检查照常过，只是走代理时没节点可用。

## App 侧（v1 范围，待实现）
- Clash 管理器：订阅链接存 App 私有 prefs；每源一个“走代理”开关（另存一份
  源 id→开关的映射，不动源记录本身）；混合端口从
  `ServicePluginManager.portOf("clash") + 1` 取。
- 走代理的源：搜索/详情/播放取链（OkHttp 系）走 `127.0.0.1:混合端口`；
  播放器 mpv 挂 `--http-proxy`；Media3 看它用的数据源再定。
  不开开关的源、以及所有不走代理的流量，一律不动。
- v1 不做：整机 VPN、按域名分流、订阅格式转换、节点测速/切换界面
  （选节点走控制 API `GET /proxies`，以后再加）。

## 安装
市场 server 分支装 zip，或服务页本地装 zip。装完在服务页启动，健康检查
过 `GET /version` 即正常。卸载即删干净，不留常驻进程。

## 合规说明
插件是用户自己装的、可选的；主包不含任何代理代码与节点；
只绑 127.0.0.1，不对外监听。订阅链接是用户自己的凭证，只存他手机本地。
