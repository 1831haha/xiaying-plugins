#!/system/bin/sh
# hello-service 1.1.1: 侠影示例服务（服务型插件参考模板）
# PORT/SERVICE_PORT 由侠影 App 启动时注入环境变量，只绑 127.0.0.1。
PORT="${PORT:-${SERVICE_PORT:-29578}}"
echo "[hello-service] 侠影示例服务 1.1.1 启动，监听 127.0.0.1:$PORT，时间 $(date '+%Y-%m-%d %H:%M:%S')"

# 处理一次请求：从 stdin 读请求行，响应写 stdout（调用方把 stdout 接到 FIFO 喂回 nc）。
serve_once() {
  IFS=' ' read -r _METHOD _PATH _REST || exit 0
  _PATH="${_PATH%%\?*}"
  case "$_PATH" in
    /healthz)
      printf 'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK'
      ;;
    *)
      BODY="侠影示例服务 hello-service 1.1.1
状态：运行中
时间：$(date '+%Y-%m-%d %H:%M:%S')
监听：127.0.0.1:$PORT
探活：GET /healthz"
      LEN=$(printf '%s' "$BODY" | wc -c | tr -d ' ')
      printf 'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: %s\r\nConnection: close\r\n\r\n%s' "$LEN" "$BODY"
      ;;
  esac
}

heartbeat() {
  echo "[hello-service] 心跳保活模式，每 5 秒一条日志（端口 $PORT 未提供 HTTP）"
  while true; do
    echo "[hello-service] heartbeat $(date '+%H:%M:%S')"
    sleep 5
  done
}

if command -v nc >/dev/null 2>&1; then
  FIFO="${TMPDIR:-.}/.hello_resp_fifo"
  rm -f "$FIFO"
  if mkfifo "$FIFO" 2>/dev/null; then
    echo "[hello-service] 使用 nc 在 127.0.0.1:$PORT 提供 HTTP（/healthz 探活、/ 状态页）"
    # FIFO 双工：nc 的 stdin 从 FIFO 读响应，请求经管道进 serve_once，
    # serve_once 的 stdout 重定向回 FIFO——两端在启动时互相 rendezvous。
    # toybox nc 会把 -l 后多余的位置参数当成连接后来执行的程序：
    # `nc -l -p PORT 127.0.0.1` 会在每次连接时 exec "127.0.0.1"，
    # 报 Permission denied、连接全失败。监听地址改用 -s 传。
    # 另：管道的退出码是 serve_once 的，mksh 又没有 PIPESTATUS，
    # nc 绑不上端口时循环会空转刷屏——把 nc 的 stderr 单独记到文件，
    # 命中 "Address already in use" 才 sleep 1 秒限速；正常请求
    # 处理完立即重绑，不留 1 秒空窗（否则探活会撞上拒连）。
    while true; do
      nc -l -s 127.0.0.1 -p "$PORT" <"$FIFO" 2>"$TMP/.nc_err" | serve_once >"$FIFO"
      if grep -q "Address already in use" "$TMP/.nc_err" 2>/dev/null; then sleep 1; fi
    done
  else
    echo "[hello-service] 无法创建 FIFO，转入心跳保活"
  fi
else
  echo "[hello-service] 系统无 nc，跳过 HTTP，转入心跳保活"
fi
heartbeat
