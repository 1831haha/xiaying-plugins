# -*- coding: utf-8 -*-
"""
BTSOW 磁力搜索 PY 爬虫 —— 豆瓣配图版
站点: https://btsow.live (btsow.com 已跳转占位页)
接口(站内 JSON,不解析 HTML):
  搜索: POST /bts/data/api/search   body: [{"search": "关键词"}, 30, 页码]
  详情: POST /bts/data/api/magnet   body: ["40位HASH"]
POST 必须带: X-CSRF-Token(首页 <meta name="csrf-token">) +
             X-Requested-With: XMLHttpRequest + 浏览器 UA(无 UA 会被拦空返回)
播放: 磁力直链,playerContent 返回 parse 0(壳子需支持磁力)

配图原理: BTSOW 只返回标题/大小/日期/hash,没有海报字段。
本版从标题里猜片名+年份,调豆瓣站内联想接口 subject_suggest(免 key)
配一张海报。配不准/配不上时留空(显示占位图),属正常情况。
代价: 列表加载会多等几秒(并发请求豆瓣),压制组标题的匹配率不足一半。
独立 Spider 类，不依赖 base.spider（DsPlayer py 插件环境无此模块）
"""
import re
import json
import sys
import urllib.parse


class Spider:
    def getName(self):
        return "BTSOW（配图）"

    def init(self, extend=""):
        self.host = "https://btsow.live"
        self.ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        self.headers = {
            "User-Agent": self.ua,
            "Referer": self.host + "/",
            "Origin": self.host,
        }
        self._csrf = ""
        self._pic_cache = {}
        # BTSOW 是纯磁力搜索站,没有真实分类,分类即关键词搜索
        self.classes = [
            {"type_id": "电影", "type_name": "电影"},
            {"type_id": "电视剧", "type_name": "电视剧"},
            {"type_id": "动漫", "type_name": "动漫"},
            {"type_id": "综艺", "type_name": "综艺"},
            {"type_id": "纪录片", "type_name": "纪录片"},
            {"type_id": "4K", "type_name": "4K"},
            {"type_id": "无损音乐", "type_name": "无损音乐"},
        ]

    # ---------------- 内部工具 ----------------
    def _csrf_token(self):
        if self._csrf:
            return self._csrf
        try:
            import requests
            r = requests.get(self.host + "/", headers={"User-Agent": self.ua}, timeout=10)
            m = re.search(r'<meta\s+name=["\']csrf-token["\']\s+content=["\']([^"\']+)["\']',
                          r.text, re.I)
            if m:
                self._csrf = m.group(1)
        except Exception:
            pass
        return self._csrf

    def _api_post(self, path, body):
        try:
            import requests
            h = dict(self.headers)
            h.update({
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest",
                "X-CSRF-Token": self._csrf_token(),
            })
            r = requests.post(self.host + path, data=json.dumps(body), headers=h, timeout=15)
            return r.json()
        except Exception:
            return {}

    @staticmethod
    def _clean(s):
        return re.sub(r"<[^>]+>", "", str(s or "")).strip()

    @staticmethod
    def _fmt_size(b):
        try:
            b = float(b)
        except Exception:
            return ""
        if b >= 1073741824:
            return "%.2fGB" % (b / 1073741824)
        if b >= 1048576:
            return "%.2fMB" % (b / 1048576)
        if b >= 1024:
            return "%.1fKB" % (b / 1024)
        return "%dB" % int(b)

    @staticmethod
    def _fmt_date(ts):
        try:
            import datetime
            ts = int(ts)
            if not ts:
                return ""
            return datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
        except Exception:
            return ""

    # ---------------- 豆瓣配图 ----------------
    _YEAR_RE = re.compile(r"\b(19\d{2}|20\d{2})\b")
    _TAG_RE = re.compile(
        r"(?i)\b(1080p|720p|480p|2160p|4k|8k|bluray|blu-?ray|web-?dl|webrip|hdrip|"
        r"bdrip|dvdrip|hdtv|x264|x265|h\.?264|h\.?265|hevc|hdr10?|dolby|dts-?hd?|"
        r"aac|ac3|eac3|truehd|remux|proper|repack|limited|extended|unrated|"
        r"directors?\.?\s*cut|imax|3d|2d|国配|中字|中英双字|内嵌字幕|"
        r"无字幕|生肉|熟肉|粤语|台配|官方|抢先版?|枪版|清晰版?|高清|超清|"
        r"ddp\d*|atmos|flac|web|dl)\b")
    _BRACKET_RE = re.compile(r"[\[\(（【].*?[\]\)）】]")

    def _guess_query(self, name):
        """从压制组标题猜出豆瓣可搜的片名和年份,返回 (query, year)。"""
        name = str(name or "")
        m = self._YEAR_RE.search(name)
        year = m.group(1) if m else ""
        head = name[:m.start()] if m else name
        head = self._BRACKET_RE.sub(" ", head)
        head = re.sub(r"[._\-]+", " ", head)
        head = self._TAG_RE.sub(" ", head)
        head = re.sub(r"(?i)\bs\d{1,2}(e\d{1,3})?\b", " ", head)  # S01/E02 季集标记
        head = re.sub(r"\s+", " ", head).strip()
        cjk = "".join(re.findall(r"[\u4e00-\u9fff]+", head))
        if cjk:
            query = cjk[:12]
        else:
            words = [w for w in head.split(" ")
                     if w and len(w) > 1 and not w.isdigit()]
            query = " ".join(words[:8])
        return query, year

    def _douban_pic(self, name):
        """返回海报 URL,配不上返回空串。结果按猜测片名缓存。"""
        query, year = self._guess_query(name)
        if not query:
            return ""
        key = query + "|" + year
        if key in self._pic_cache:
            return self._pic_cache[key]
        pic = ""
        try:
            import requests
            # 查询词逐级缩短兜底: 全词 -> 去掉末尾词,直到剩 2 个词
            queries = [query]
            words = query.split(" ")
            while len(words) > 2:
                words = words[:-1]
                queries.append(" ".join(words))
            headers = {"User-Agent": self.ua, "Referer": "https://movie.douban.com/"}
            for q in queries:
                url = ("https://movie.douban.com/j/subject_suggest?q="
                       + urllib.parse.quote(q))
                r = requests.get(url, headers=headers, timeout=6)
                cands = r.json()
                if not (isinstance(cands, list) and cands):
                    continue
                pick = None
                for c in cands:
                    if year and str(c.get("year", "")) == year:
                        pick = c
                        break
                if pick is None and not year:
                    # 没年份可比对时才取首个候选
                    pick = cands[0]
                if pick is None:
                    # 有年份但对不上: 宁可缺图也不配错图,换更短的词再试
                    continue
                img = str(pick.get("img", "") or "")
                if img:
                    # s_ratio_poster 是小图,换 m 档清晰度更好
                    pic = img.replace("s_ratio_poster", "m_ratio_poster")
                break
        except Exception:
            pic = ""
        self._pic_cache[key] = pic
        return pic

    def _enrich_pics(self, items):
        """并发给列表条目配海报,失败的条目保持占位图。"""
        if not items:
            return
        try:
            from concurrent.futures import ThreadPoolExecutor
        except Exception:
            return
        names = [it.get("vod_name", "") for it in items]

        def work(n):
            try:
                return self._douban_pic(n)
            except Exception:
                return ""

        try:
            with ThreadPoolExecutor(max_workers=6) as ex:
                pics = list(ex.map(work, names))
        except Exception:
            return
        for it, p in zip(items, pics):
            if p:
                it["vod_pic"] = p

    def _search(self, keyword, page):
        try:
            page = int(page)
        except Exception:
            page = 1
        j = self._api_post("/bts/data/api/search", [{"search": keyword}, 30, page])
        if not isinstance(j, dict) or j.get("code") != 200 or not isinstance(j.get("data"), list):
            return []
        items = []
        for e in j["data"]:
            h = str(e.get("hash", "")).strip()
            if not h:
                continue
            name = self._clean(e.get("name"))
            remark = ("%s %s" % (self._fmt_size(e.get("size")),
                                 self._fmt_date(e.get("lastUpdateTime")))).strip()
            items.append({
                "vod_id": h,
                "vod_name": name,
                "vod_pic": "",
                "vod_remarks": remark,
            })
        self._enrich_pics(items)
        return items

    def _detail(self, h):
        h = str(h or "").strip().upper()
        j = self._api_post("/bts/data/api/magnet", [h])
        d = j.get("data") if isinstance(j, dict) else None
        if not isinstance(d, dict):
            d = {}
        name = self._clean(d.get("name")) or h
        files = d.get("files") if isinstance(d.get("files"), list) else []
        total = d.get("size") or 0
        ts = d.get("lastUpdateTime") or 0
        flist = "\n".join("%s  [%s]" % (f.get("filename", ""),
                                        self._fmt_size(f.get("size"))) for f in files)
        magnet = "magnet:?xt=urn:btih:" + h
        if name and name != h:
            magnet += "&dn=" + urllib.parse.quote(name)
        play_name = re.sub(r"[$#]", "", name)
        content = "共 %d 个文件" % len(files)
        if flist:
            content += "\n" + flist
        return {
            "vod_id": h,
            "vod_name": name,
            "vod_pic": self._douban_pic(name),
            "vod_remarks": self._fmt_size(total),
            "vod_year": self._fmt_date(ts)[:4],
            "vod_content": content,
            "vod_play_from": "磁力",
            "vod_play_url": "%s$%s" % (play_name, magnet),
        }

    # ---------------- 标准接口 ----------------
    def homeContent(self, filter=True):
        return {"class": self.classes, "filters": {}}

    def homeVideoContent(self):
        return {"list": self._search("电影", 1)}

    def categoryContent(self, tid, pg=1, filter=True, extend=None):
        try:
            page = int(pg)
        except Exception:
            page = 1
        keyword = str(tid or "电影")
        lst = self._search(keyword, page)
        return {
            "page": page,
            "pagecount": 9999 if len(lst) >= 30 else page,
            "limit": 30,
            "total": 999999,
            "list": lst,
        }

    def detailContent(self, ids):
        return {"list": [self._detail(i) for i in ids if str(i or "").strip()]}

    def searchContent(self, key, quick=False, pg="1"):
        try:
            page = int(pg)
        except Exception:
            page = 1
        return {"list": self._search(key, page), "page": page}

    def playerContent(self, flag, id, vipFlags):
        url = str(id or "").strip()
        return {"parse": 0, "url": url}
