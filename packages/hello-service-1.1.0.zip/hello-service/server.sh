#!/system/bin/sh
# hello-service 1.1.0: 侠影示例服务（服务型插件参考模板）
# PORT/SERVICE_PORT 由侠影 App 启动时注入环境变量，只绑 127.0.0.1。
PORT="${PORT:-${SERVICE_PORT:-29578}}"
echo "[hello-service] 侠影示例服务 1.1.0 启动，监听 127.0.0.1:$PORT，时间 $(date '+%Y-%m-%d %H:%M:%S')"

# 处理一次请求：从 stdin 读请求行，响应写 stdout（调用方把 stdout 接到 FIFO 喂回 nc）。
serve_once() {
  IFS=' ' read -r _METHOD _PATH _REST || exit 0
  _PATH="${_PATH%%\?*}"
  case "$_PATH" in
    /healthz)
      printf 'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK'
      ;;
    *)
      BODY="侠影示例服务 hello-service 1.1.0
状态：运行中
时间：$(date '+%Y-%m-%d %H:%M:%S')
监听：127.0.0.1:$PORT
探活：GET /healthz"
      LEN=$(printf '%s' "$BODY" | wc -c | tr -d ' ')
      printf 'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: %s\r\nConnection: close\r\n\r\n%s' "$LEN" "$BODY"
      ;;
  esac
}

heartbeat() {
  echo "[hello-service] 心跳保活模式，每 5 秒一条日志（端口 $PORT 未提供 HTTP）"
  while true; do
    echo "[hello-service] heartbeat $(date '+%H:%M:%S')"
    sleep 5
  done
}

if command -v nc >/dev/null 2>&1; then
  FIFO="${TMPDIR:-.}/.hello_resp_fifo"
  rm -f "$FIFO"
  if mkfifo "$FIFO" 2>/dev/null; then
    echo "[hello-service] 使用 nc 在 127.0.0.1:$PORT 提供 HTTP（/healthz 探活、/ 状态页）"
    # FIFO 双工：nc 的 stdin 从 FIFO 读响应，请求经管道进 serve_once，
    # serve_once 的 stdout 重定向回 FIFO——两端在启动时互相 rendezvous。
    while true; do
      nc -l -p "$PORT" 127.0.0.1 <"$FIFO" | serve_once >"$FIFO" || break
    done
    echo "[hello-service] nc 服务循环退出（参数可能不兼容），转入心跳保活"
    rm -f "$FIFO"
  else
    echo "[hello-service] 无法创建 FIFO，转入心跳保活"
  fi
else
  echo "[hello-service] 系统无 nc，跳过 HTTP，转入心跳保活"
fi
heartbeat
